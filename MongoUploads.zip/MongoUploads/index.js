const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const crypto = require ('crypto');
const mongoose = require('mongoose');
const multer = require('multer');
const gridFsStorage = require('multer-gridfs-storage');
const Grid = require('gridfs-stream');
const methodOverride = require('method-override');


const app = express();

app.use(bodyParser.json());
app.use(methodOverride('_method'));
app.set('view engine', 'ejs');

const mongoURI = 'mongodb+srv://PASSIONFROID:Azerty123@cluster0.e01xb.mongodb.net/myFirstDatabase?retryWrites=true&w=majority';

const conn = mongoose.createConnection(mongoURI);

let gfs;

conn.once('open', function () {
    gfs = Grid(conn.db, mongoose.mongo);
    gfs.collection('uploads');
})

const storage = new gridFsStorage({
    url: mongoURI,
    file: (req, file) => {
      return new Promise((resolve, reject) => {
        crypto.randomBytes(16, (err, buf) => {
          if (err) {
            return reject(err);
          }
          const filename = buf.toString('hex') + path.extname(file.originalname);
          const fileInfo = {
            filename: filename,
            bucketName: 'uploads'
          };
          resolve(fileInfo);
        });
      });
    }
  });
  const upload = multer({ storage });
  
// ça merde ici
app.get('/', (req, res) =>  {
    gfs.files.find().toArray((err, files) => {
        if(!files || files.lenght === 0) {
           res.render('index', {files: false});
        } else{
            files.map(file => {
                if(file.contentType === 'image/jpeg' || file.contentType === 'image/png')
                {
                    file.isImage = true;
                } else {
                    file.isImage = false;
                }

            });
            res.render('index', {files: files});
        }
       
    });
});

app.post('/upload', upload.single('file'), (req, res) => {
res.redirect('/');
});

// ROUTE /FILES

app.get('/files', (req, res) => {
    gfs.files.find().toArray((err, files) =>{
        if(!files || files.lenght === 0) {
            return res.status(404).json({
                err: 'Aucun fichier existant'
            });
        }
        return res.json(files);
    });
});

// ROUTE /FILES

app.get('/files/:filename', (req, res) => {
    gfs.files.findOne({filename: req.params.filename}, (err, file) => {
        if(!file || file.lenght === 0) {
            return res.status(404).json({
                err: 'Aucun fichier existant'
            });
    }
    return res.json(file);
});
});

app.get('/image/:filename', (req, res) => {
    gfs.files.findOne({filename: req.params.filename}, (err, file) => {
        if(!file || file.lenght === 0) {
            return res.status(404).json({
                err: 'Aucun fichier existant'
            });
    }
    if(file.contentType ==='image/jpeg' || file.contentType === 'image/png'){
        const readstream = gfs.createReadStream(file.filename);
        readstream.pipe(res);
    } else {
        res.status(404).json({
            err: "Ce n'est pas une image"
        });
    }
    });
});

app.delete('/files/:id', (req, res) => {
    gfs.remove({_id: req.params.id, root: 'uploads'}, (err, gridStore) => {
       if(err) {
           return res.status(404).json({ err : err });
       } 
       res.redirect('/');
    });
});

const port = 5000;

app.listen(port, () => console.log(`Server stated on port ${port}`));